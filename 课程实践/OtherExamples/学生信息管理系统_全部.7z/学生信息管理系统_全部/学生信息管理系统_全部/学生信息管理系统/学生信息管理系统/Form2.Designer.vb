﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.信息管理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.学生信息管理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.课程信息管理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.班级信息管理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.成绩信息管理ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.成绩信息管理ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.学生信息查询ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.成绩信息查询ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.退出系统QToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("微软雅黑", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.信息管理ToolStripMenuItem, Me.成绩信息管理ToolStripMenuItem1, Me.退出系统QToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(947, 29)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        '信息管理ToolStripMenuItem
        '
        Me.信息管理ToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.学生信息管理ToolStripMenuItem, Me.课程信息管理ToolStripMenuItem, Me.班级信息管理ToolStripMenuItem, Me.成绩信息管理ToolStripMenuItem})
        Me.信息管理ToolStripMenuItem.Name = "信息管理ToolStripMenuItem"
        Me.信息管理ToolStripMenuItem.Size = New System.Drawing.Size(86, 25)
        Me.信息管理ToolStripMenuItem.Text = "信息管理"
        '
        '学生信息管理ToolStripMenuItem
        '
        Me.学生信息管理ToolStripMenuItem.Name = "学生信息管理ToolStripMenuItem"
        Me.学生信息管理ToolStripMenuItem.Size = New System.Drawing.Size(176, 26)
        Me.学生信息管理ToolStripMenuItem.Text = "学生信息管理"
        '
        '课程信息管理ToolStripMenuItem
        '
        Me.课程信息管理ToolStripMenuItem.Name = "课程信息管理ToolStripMenuItem"
        Me.课程信息管理ToolStripMenuItem.Size = New System.Drawing.Size(176, 26)
        Me.课程信息管理ToolStripMenuItem.Text = "课程信息管理"
        '
        '班级信息管理ToolStripMenuItem
        '
        Me.班级信息管理ToolStripMenuItem.Name = "班级信息管理ToolStripMenuItem"
        Me.班级信息管理ToolStripMenuItem.Size = New System.Drawing.Size(176, 26)
        Me.班级信息管理ToolStripMenuItem.Text = "班级信息管理"
        '
        '成绩信息管理ToolStripMenuItem
        '
        Me.成绩信息管理ToolStripMenuItem.Name = "成绩信息管理ToolStripMenuItem"
        Me.成绩信息管理ToolStripMenuItem.Size = New System.Drawing.Size(176, 26)
        Me.成绩信息管理ToolStripMenuItem.Text = "成绩信息管理"
        '
        '成绩信息管理ToolStripMenuItem1
        '
        Me.成绩信息管理ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.学生信息查询ToolStripMenuItem, Me.成绩信息查询ToolStripMenuItem})
        Me.成绩信息管理ToolStripMenuItem1.Name = "成绩信息管理ToolStripMenuItem1"
        Me.成绩信息管理ToolStripMenuItem1.Size = New System.Drawing.Size(86, 25)
        Me.成绩信息管理ToolStripMenuItem1.Text = "信息查询"
        '
        '学生信息查询ToolStripMenuItem
        '
        Me.学生信息查询ToolStripMenuItem.Name = "学生信息查询ToolStripMenuItem"
        Me.学生信息查询ToolStripMenuItem.Size = New System.Drawing.Size(176, 26)
        Me.学生信息查询ToolStripMenuItem.Text = "学生信息查询"
        '
        '成绩信息查询ToolStripMenuItem
        '
        Me.成绩信息查询ToolStripMenuItem.Name = "成绩信息查询ToolStripMenuItem"
        Me.成绩信息查询ToolStripMenuItem.Size = New System.Drawing.Size(176, 26)
        Me.成绩信息查询ToolStripMenuItem.Text = "成绩信息查询"
        '
        '退出系统QToolStripMenuItem
        '
        Me.退出系统QToolStripMenuItem.Name = "退出系统QToolStripMenuItem"
        Me.退出系统QToolStripMenuItem.Size = New System.Drawing.Size(109, 25)
        Me.退出系统QToolStripMenuItem.Text = "退出系统(&Q)"
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(947, 446)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Form2"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "学生管理系统"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents 信息管理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成绩信息管理ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 退出系统QToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 学生信息管理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 课程信息管理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 班级信息管理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成绩信息管理ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 学生信息查询ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents 成绩信息查询ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
