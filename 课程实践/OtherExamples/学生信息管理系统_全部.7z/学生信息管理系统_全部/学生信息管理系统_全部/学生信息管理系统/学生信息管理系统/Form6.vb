﻿Imports System.Data.SqlClient
Public Class Form6
    Dim cn As SqlConnection
    Dim cm As SqlCommand
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim myReader As SqlDataReader

    Private Sub Form6_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ModMain.GetConn()
        ReadSocre()
        ReadKC()
    End Sub
    Private Sub ReadKC()
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [课程信息表]"
        cn.Open()
        myReader = cm.ExecuteReader
        Do While myReader.Read
            ComboBox1.Items.Add(myReader("课程编号"))
        Loop
        ComboBox1.Text = ComboBox1.Items(0)
        myReader.Close()
        cn.Close()
    End Sub
    Private Sub ReadSocre()
        cn = New SqlConnection(strConn)
        '这里的链接默认就是打开的
        da = New SqlDataAdapter("select * from [成绩信息表]", cn)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Columns(0).Width = 120
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 120
        DataGridView1.Columns(3).Width = 150
        TextBox1.Text = ""
        TextBox2.Text = ""
    End Sub

    Private Sub ComboBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.Click
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [课程信息表] where 课程编号='" & ComboBox1.Text & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            TextBox3.Text = myReader("课程名称")
        End If
        ComboBox1.Text = ComboBox1.Items(0)
        myReader.Close()
        cn.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Then
            MsgBox("学生学号不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            MsgBox("学生成绩不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If

        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [成绩信息表] where 学生课程号='" & Trim(TextBox1.Text) & ComboBox1.Text & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            MsgBox("该学生的该课程成绩已经存在，请检查！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        Else
            myReader.Close()
            cn.Close()
        End If
        cn = New SqlConnection(strConn)
        cn.Open()
        Dim SqlString As String = "INSERT INTO 成绩信息表 VALUES ("
        SqlString = SqlString & "'" & Trim(TextBox1.Text) & ComboBox1.Text & "','" & Trim(TextBox1.Text) & "','" & Trim(ComboBox1.Text) & "'," & Val(TextBox2.Text) & ")"
        cm = New SqlCommand(SqlString, cn)
        cm.ExecuteNonQuery()
        cn.Close()
        MsgBox("成绩信息添加完成！")
        ReadSocre()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            MsgBox("学生学号不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            MsgBox("学生成绩不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [成绩信息表] where 学生学号='" & Trim(TextBox1.Text) & "' and 课程编号='" & ComboBox1.Text & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            myReader.Close()
            cn.Close()
        Else
            MsgBox("该学生的该课程信息不存在，请检查！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cn.Open()
        Dim SqlString As String
        SqlString = "UPDATE 成绩信息表 SET 学生成绩=" & Trim(TextBox2.Text) & " "
        
        SqlString = SqlString & "where 学生课程号='" & Trim(TextBox1.Text) & ComboBox1.Text & "'"
        cm = New SqlCommand(SqlString, cn)
        cm.ExecuteNonQuery()
        cn.Close()
        MsgBox("成绩信息修改成功！", vbOKOnly + vbInformation, "提示信息：")
        ReadSocre()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Then
            MsgBox("学生学号不能为空，请先选择要删除的成绩信息！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [成绩信息表] where 学生学号='" & Trim(TextBox1.Text) & "' and 课程编号='" & ComboBox1.Text & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            myReader.Close()
            cn.Close()
        Else
            MsgBox("该学生的该课程成绩信息在数据库中不存在，请检查！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        End If
        Dim temp As MsgBoxResult
        temp = MsgBox("确实要删除此条成绩信息记录吗?", MsgBoxStyle.YesNo, "提示信息:")
        If temp = MsgBoxResult.Yes Then
            cn = New SqlConnection(strConn)
            cm = New SqlCommand
            cm.Connection = cn
            cm.CommandText = "delete from [成绩信息表] where 学生课程号 ='" & Trim(TextBox1.Text) & ComboBox1.Text & "'"
            cn.Open()
            cm.ExecuteNonQuery()
            cn.Close()
            ReadSocre()
        Else
            Exit Sub
        End If
    End Sub
End Class