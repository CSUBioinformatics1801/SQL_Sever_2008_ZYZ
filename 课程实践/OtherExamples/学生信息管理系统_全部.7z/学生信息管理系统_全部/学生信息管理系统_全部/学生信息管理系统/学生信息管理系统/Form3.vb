﻿Imports System.Data.SqlClient
Public Class Form3
    Dim cn As SqlConnection
    Dim cm As SqlCommand
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim myReader As SqlDataReader
    Dim TTs As String
    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ModMain.GetConn()
        ReadStuInfo()
        ComboBox1.Items.Add("男")
        ComboBox1.Items.Add("女")
        ComboBox1.Text = "男"
        ComboBox2.Items.Add("通信工程学院")
        ComboBox2.Items.Add("机电工程学院")
        ComboBox2.Items.Add("经济学院")
        ComboBox2.Items.Add("机械工程学院")
        ComboBox2.Items.Add("工商管理学院")
        ComboBox2.Items.Add("外语学院")

        ComboBox3.Items.Add("群众")
        ComboBox3.Items.Add("团员")
        ComboBox3.Items.Add("党员")
        ComboBox3.Text = "群众"

        ComboBox4.Items.Add("学生学号")
        ComboBox4.Items.Add("学生姓名")
        ComboBox4.Items.Add("所属院系")
        ComboBox4.Items.Add("所属班级")
        ComboBox4.Items.Add("政治面貌")
        ComboBox4.Items.Add("学生性别")
        ComboBox4.Text = ComboBox4.Items(0)
    End Sub
    Private Sub ReadStuInfo()
        cn = New SqlConnection(strConn)
        '这里的链接默认就是打开的
        da = New SqlDataAdapter("select 学生学号,学生姓名,学生性别,出生日期,所属院系,所属班级,联系电话 from [学生信息表]", cn)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Columns(0).Width = 100
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 100
        DataGridView1.Columns(3).Width = 100
        DataGridView1.Columns(4).Width = 100
        DataGridView1.Columns(5).Width = 125
        DataGridView1.Columns(6).Width = 150
        ClearT()
    End Sub
    Private Sub ReadStuInfo1(ByVal s1 As String)
        cn = New SqlConnection(strConn)
        '这里的链接默认就是打开的
        da = New SqlDataAdapter("select 学生学号,学生姓名,学生性别,出生日期,所属院系,所属班级,联系电话 from [学生信息表] where " & ComboBox4.Text & " like '%" & s1 & "%'", cn)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Columns(0).Width = 100
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 100
        DataGridView1.Columns(3).Width = 100
        DataGridView1.Columns(4).Width = 100
        DataGridView1.Columns(5).Width = 125
        DataGridView1.Columns(6).Width = 150
        ClearT()
    End Sub
    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Me.Close()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Then
            MsgBox("学生学号不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            MsgBox("学生姓名不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If ComboBox2.Text = "" Then
            MsgBox("所属院系不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox3.Text = "" Then
            MsgBox("所属班级不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox4.Text = "" Then
            MsgBox("联系邮箱不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox5.Text = "" Then
            MsgBox("联系电话不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox6.Text = "" Then
            MsgBox("第二联系人联系电话不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox7.Text = "" Then
            MsgBox("第二联系人不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox8.Text = "" Then
            MsgBox("家庭地址不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [学生信息表] where 学生学号='" & Trim(TextBox1.Text) & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            MsgBox("该学生学号已经存在，请勿重复添加！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        Else
            myReader.Close()
            cn.Close()
        End If
        cn = New SqlConnection(strConn)
        cn.Open()
        Dim SqlString As String = "INSERT INTO 学生信息表 (学生学号,学生姓名,学生性别,出生日期,所属院系,所属班级,联系电话,联系邮箱,家庭地址,政治面貌,第二联系人,第二联系人电话) VALUES ("
        SqlString = SqlString & "'" & Trim(TextBox1.Text) & "','" & Trim(TextBox2.Text) & "','" & Trim(ComboBox1.Text) & "','" & Format(DateTimePicker1.Value, "yyyy-MM-dd") & "','" & Trim(ComboBox2.Text) & "','" & Trim(TextBox3.Text) & "','" & Trim(TextBox5.Text) & "','" & Trim(TextBox4.Text) & "','" & Trim(TextBox8.Text) & "','" & Trim(ComboBox3.Text) & "','" & Trim(TextBox7.Text) & "','" & Trim(TextBox6.Text) & "')"
        cm = New SqlCommand(SqlString, cn)
        cm.ExecuteNonQuery()
        cn.Close()
        UpdateImage(Trim(TextBox1.Text))
        MsgBox("学生信息添加完成！")
        ReadStuInfo()
    End Sub
    Private Sub UpdateImage(ByVal s As String)
        If CStr(Me.PictureBox1.ImageLocation).Trim() <> "" Then
            Try
                Dim sSql1 As String = ""
                'sSql1 = "insert into U_CallInfoSet(backImage) values(@fs)"  //插入或者更新语句  
                sSql1 = "update 学生信息表 set 学生照片=@fs where 学生学号='" & s & "'"
                ModMain.ExecuteSqlWithImg(sSql1, My.Computer.FileSystem.ReadAllBytes(Me.PictureBox1.ImageLocation))
            Catch ex As Exception
                MessageBox.Show(ex.ToString())
            End Try
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        If TextBox1.Text = "" Then
            MsgBox("学生学号不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            MsgBox("学生姓名不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If ComboBox2.Text = "" Then
            MsgBox("所属院系不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox3.Text = "" Then
            MsgBox("所属班级不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox4.Text = "" Then
            MsgBox("联系邮箱不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox5.Text = "" Then
            MsgBox("联系电话不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox6.Text = "" Then
            MsgBox("第二联系人联系电话不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox7.Text = "" Then
            MsgBox("第二联系人不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox8.Text = "" Then
            MsgBox("家庭地址不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [学生信息表] where 学生学号='" & Trim(TextBox1.Text) & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            myReader.Close()
            cn.Close()
        Else
            MsgBox("该学生学号的信息未登记，请先登记后再修改！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cn.Open()
        Dim SqlString As String
        SqlString = "UPDATE 学生信息表 SET 学生姓名='" & Trim(TextBox2.Text) & "',"
        SqlString = SqlString & "学生性别='" & Trim(ComboBox1.Text) & "',"
        SqlString = SqlString & "出生日期='" & Format(DateTimePicker1.Value, "yyyy-MM-dd") & "',"
        SqlString = SqlString & "所属院系='" & Trim(ComboBox2.Text) & "',"
        SqlString = SqlString & "所属班级='" & Trim(TextBox3.Text) & "',"
        SqlString = SqlString & "联系邮箱='" & Trim(TextBox4.Text) & "',"
        SqlString = SqlString & "联系电话='" & Trim(TextBox5.Text) & "',"
        SqlString = SqlString & "政治面貌='" & Trim(ComboBox3.Text) & "',"
        SqlString = SqlString & "家庭地址='" & Trim(TextBox8.Text) & "',"
        SqlString = SqlString & "第二联系人='" & Trim(TextBox7.Text) & "',"
        SqlString = SqlString & "第二联系人电话='" & Trim(TextBox6.Text) & "' where 学生学号='" & Trim(TextBox1.Text) & "'"
        cm = New SqlCommand(SqlString, cn)
        cm.ExecuteNonQuery()
        cn.Close()
        UpdateImage(Trim(TextBox1.Text))
        MsgBox("学生信息修改成功！", vbOKOnly + vbInformation, "提示信息：")
        ReadStuInfo()
    End Sub
    Private Sub ClearT()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        Me.PictureBox1.Image = Image.FromFile(Application.StartupPath & "\Image\null.jpg")
        Me.PictureBox1.ImageLocation = Application.StartupPath & "\Image\null.jpg"
    End Sub
    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If TextBox1.Text = "" Then
            MsgBox("学生学号不能为空，请先选择要删除的学生信息！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [学生信息表] where 学生学号='" & Trim(TextBox1.Text) & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            myReader.Close()
            cn.Close()
        Else
            MsgBox("该学生学号在数据库中不存在，请检查！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        End If
        Dim temp As MsgBoxResult
        temp = MsgBox("确实要删除此条学生信息记录吗?", MsgBoxStyle.YesNo, "提示信息:")
        If temp = MsgBoxResult.Yes Then
            cn = New SqlConnection(strConn)
            cm = New SqlCommand
            cm.Connection = cn
            cm.CommandText = "delete from [学生信息表] where 学生学号 ='" & Trim(TextBox1.Text) & "'"
            cn.Open()
            cm.ExecuteNonQuery()
            cn.Close()
            ReadStuInfo()
        Else
            Exit Sub
        End If
    End Sub
    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        If e.RowIndex >= 0 Then
            TextBox1.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(0).Value.ToString)
            TextBox2.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(1).Value.ToString)
            ComboBox1.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(2).Value.ToString)
            DateTimePicker1.Value = Trim(DataGridView1.Rows(e.RowIndex).Cells(3).Value.ToString)
            ComboBox2.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(4).Value.ToString)
            TextBox3.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(5).Value.ToString)
            TextBox5.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(6).Value.ToString)
            
            cn = New SqlConnection(strConn)
            cm = New SqlCommand
            cm.Connection = cn
            cm.CommandText = "select * from [学生信息表] where 学生学号='" & Trim(TextBox1.Text) & "'"
            cn.Open()
            myReader = cm.ExecuteReader
            If myReader.Read Then
                If myReader("联系邮箱") Is DBNull.Value Then
                    TextBox4.Text = ""
                Else
                    TextBox4.Text = myReader("联系邮箱")
                End If
                If myReader("政治面貌") Is DBNull.Value Then
                    ComboBox3.Text = "群众"
                Else
                    ComboBox3.Text = myReader("政治面貌")
                End If
                If myReader("第二联系人") Is DBNull.Value Then
                    TextBox7.Text = ""
                Else
                    TextBox7.Text = myReader("第二联系人")
                End If
                If myReader("第二联系人电话") Is DBNull.Value Then
                    TextBox6.Text = ""
                Else
                    TextBox6.Text = myReader("第二联系人电话")
                End If
                If myReader("家庭地址") Is DBNull.Value Then
                    TextBox8.Text = ""
                Else
                    TextBox8.Text = myReader("家庭地址")
                End If
                If myReader("学生照片") Is DBNull.Value Then
                    Me.PictureBox1.Image = Image.FromFile(Application.StartupPath & "\Image\null.jpg")
                    Me.PictureBox1.ImageLocation = Application.StartupPath & "\Image\null.jpg"
                Else
                    Me.PictureBox1.Image = GetImage(myReader("学生照片"))
                    Me.PictureBox1.ImageLocation = ""
                End If
                myReader.Close()
                cn.Close()
            End If
        End If
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim L_Err As String = ""
        Dim opd As OpenFileDialog = New OpenFileDialog()
        opd.CheckFileExists = True
        opd.CheckPathExists = True
        opd.RestoreDirectory = True
        opd.DefaultExt = "*.*"
        opd.Filter = "图像文件 (*.bmp;*.gif;*.jpg;*.jpeg;*.png)|*.bmp;*.gif;*.jpg;*.jpeg;*.png"
        opd.ShowDialog()
        If opd.FileName <> "" Then
            Me.PictureBox1.Image = Image.FromFile(opd.FileName)
            Me.PictureBox1.ImageLocation = opd.FileName
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.PictureBox1.Image = Image.FromFile(Application.StartupPath & "\Image\null.jpg")
        Me.PictureBox1.ImageLocation = Application.StartupPath & "\Image\null.jpg"
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If Trim(TextBox9.Text) = "" Then
            ReadStuInfo()
        Else
            ReadStuInfo1(Trim(TextBox9.Text))
        End If
    End Sub
End Class