﻿Imports System.Data.SqlClient
Public Class Form5
    Dim cn As SqlConnection
    Dim cm As SqlCommand
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim myReader As SqlDataReader

    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ModMain.GetConn()
        ReadBJInfo()
    End Sub
    Private Sub ReadBJInfo()
        cn = New SqlConnection(strConn)
        '这里的链接默认就是打开的
        da = New SqlDataAdapter("select * from [班级信息表]", cn)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Columns(0).Width = 100
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 120
        DataGridView1.Columns(3).Width = 150
        DataGridView1.Columns(4).Width = 100
        DataGridView1.Columns(5).Width = 150
        ClearT()
    End Sub
    Private Sub ClearT()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub
    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        If e.RowIndex >= 0 Then
            TextBox1.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(0).Value.ToString)
            TextBox2.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(1).Value.ToString)
            TextBox3.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(2).Value.ToString)
            TextBox4.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(3).Value.ToString)
            TextBox5.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(4).Value.ToString)
            TextBox6.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(5).Value.ToString)
        End If
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Then
            MsgBox("班级编号不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            MsgBox("班级人数不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox3.Text = "" Then
            MsgBox("班主任姓名不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox4.Text = "" Then
            MsgBox("班主任联系电话不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox5.Text = "" Then
            MsgBox("班长姓名不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox6.Text = "" Then
            MsgBox("班长联系电话不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [班级信息表] where 班级编号='" & Trim(TextBox1.Text) & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            MsgBox("该班级编号已经存在，请使用其他班级编号进行添加！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        Else
            myReader.Close()
            cn.Close()
        End If
        cn = New SqlConnection(strConn)
        cn.Open()
        Dim SqlString As String = "INSERT INTO 班级信息表 VALUES ("
        SqlString = SqlString & "'" & Trim(TextBox1.Text) & "'," & Trim(TextBox2.Text) & ",'" & Trim(TextBox3.Text) & "','" & Trim(TextBox4.Text) & "','" & Trim(TextBox5.Text) & "','" & Trim(TextBox6.Text) & "')"
        cm = New SqlCommand(SqlString, cn)
        cm.ExecuteNonQuery()
        cn.Close()
        MsgBox("班级信息添加完成！")
        ReadBJInfo()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            MsgBox("班级编号不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            MsgBox("班级人数不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox3.Text = "" Then
            MsgBox("班主任姓名不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox4.Text = "" Then
            MsgBox("班主任联系电话不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox5.Text = "" Then
            MsgBox("班长姓名不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox6.Text = "" Then
            MsgBox("班长联系电话不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [班级信息表] where 班级编号='" & Trim(TextBox1.Text) & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            myReader.Close()
            cn.Close()
        Else
            MsgBox("该班级编号信息不存在，请检查！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cn.Open()
        Dim SqlString As String
        SqlString = "UPDATE 班级信息表 SET 班级人数=" & Trim(TextBox2.Text) & ","
        SqlString = SqlString & "班主任姓名='" & Trim(TextBox3.Text) & "',"
        SqlString = SqlString & "班主任联系电话='" & Trim(TextBox4.Text) & "',"
        SqlString = SqlString & "班长姓名='" & Trim(TextBox5.Text) & "',"
        SqlString = SqlString & "班长联系电话='" & Trim(TextBox6.Text) & "' "
        SqlString = SqlString & "where 班级编号='" & Trim(TextBox1.Text) & "'"
        cm = New SqlCommand(SqlString, cn)
        cm.ExecuteNonQuery()
        cn.Close()
        MsgBox("班级信息修改成功！", vbOKOnly + vbInformation, "提示信息：")
        ReadBJInfo()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Then
            MsgBox("班级编号不能为空，请先选择要删除的班级信息！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [班级信息表] where 班级编号='" & Trim(TextBox1.Text) & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            myReader.Close()
            cn.Close()
        Else
            MsgBox("该班级编号在数据库中不存在，请检查！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        End If
        Dim temp As MsgBoxResult
        temp = MsgBox("确实要删除此条班级信息记录吗?", MsgBoxStyle.YesNo, "提示信息:")
        If temp = MsgBoxResult.Yes Then
            cn = New SqlConnection(strConn)
            cm = New SqlCommand
            cm.Connection = cn
            cm.CommandText = "delete from [班级信息表] where 班级编号 ='" & Trim(TextBox1.Text) & "'"
            cn.Open()
            cm.ExecuteNonQuery()
            cn.Close()
            ReadBJInfo()
        Else
            Exit Sub
        End If
    End Sub
End Class