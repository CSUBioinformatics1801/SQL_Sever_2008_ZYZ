﻿Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient

Module ModMain
    Public strConn As String
    Public stockTemp As Long

    Public UserName As String
    Public UserType As String
    Public UserPassWord As String
    Public Sub GetConn()
        '从配置文件得到连接字符串
        Dim strFileName As String = "mag.ini"
        Dim objReader As StreamReader = New StreamReader(strFileName)
        strConn = objReader.ReadToEnd()
        objReader.Close()
        objReader = Nothing
    End Sub
    ''' <summary>  
    ''' 字节数组转换为Image类型  
    ''' </summary>  
    ''' <param name="bData"></param>  
    ''' <returns></returns>  
    ''' <remarks></remarks>  
    Public Function GetImage(ByVal bData As Byte()) As Image
        Try
            Using fStream As Stream = New MemoryStream(bData.Length)
                Dim bWriter As New BinaryWriter(fStream)
                bWriter.Write(DirectCast(bData, Byte()))
                bWriter.Flush()
                Dim bitMap As New System.Drawing.Bitmap(fStream)
                bWriter.Close()
                fStream.Close()
                Dim iImage As Image = System.Drawing.Image.FromHbitmap(bitMap.GetHbitmap())
                Return iImage
            End Using
        Catch e As System.IO.IOException
            Throw New Exception(e.Message & "Read image data error!")
        End Try
    End Function
    ''' <summary>  
    ''' 处理SQL中操作Image类型  
    ''' </summary>  
    ''' <param name="strSQL">SQL语句</param>  
    ''' <param name="fs">图像字节,数据库的字段类型为image的情况</param>  
    ''' <returns>影响的记录数</returns>  
    Public Function ExecuteSqlWithImg(ByVal strSQL As String, ByVal fs As Byte()) As Integer
        Dim strCon As String = strConn
        Using connection As New SqlConnection(strCon)
            Dim cmd As New SqlCommand(strSQL, connection)
            Dim myParameter As New System.Data.SqlClient.SqlParameter("@fs", SqlDbType.Image)
            myParameter.Value = fs
            cmd.Parameters.Add(myParameter)
            Try
                connection.Open()
                Dim rows As Integer = cmd.ExecuteNonQuery()
                Return rows
            Catch e As System.Data.SqlClient.SqlException
                Throw e
            Finally
                cmd.Dispose()
                connection.Close()
            End Try
        End Using
    End Function
End Module