﻿Imports System.Data.SqlClient
Public Class Form7
    Dim cn As SqlConnection
    Dim cm As SqlCommand
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim myReader As SqlDataReader
    Dim TTs As String
   
    Private Sub ReadStuInfo()
        cn = New SqlConnection(strConn)
        '这里的链接默认就是打开的
        da = New SqlDataAdapter("select 学生学号,学生姓名,学生性别,出生日期,所属院系,所属班级,联系电话 from [学生信息表]", cn)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Columns(0).Width = 100
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 100
        DataGridView1.Columns(3).Width = 100
        DataGridView1.Columns(4).Width = 100
        DataGridView1.Columns(5).Width = 125
        DataGridView1.Columns(6).Width = 150
        ClearT()
    End Sub
    Private Sub ReadStuInfo1(ByVal s1 As String)
        cn = New SqlConnection(strConn)
        '这里的链接默认就是打开的
        da = New SqlDataAdapter("select 学生学号,学生姓名,学生性别,出生日期,所属院系,所属班级,联系电话 from [学生信息表] where " & ComboBox4.Text & " like '%" & s1 & "%'", cn)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Columns(0).Width = 100
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 100
        DataGridView1.Columns(3).Width = 100
        DataGridView1.Columns(4).Width = 100
        DataGridView1.Columns(5).Width = 125
        DataGridView1.Columns(6).Width = 150
        ClearT()
    End Sub
    Private Sub ClearT()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        Me.PictureBox1.Image = Image.FromFile(Application.StartupPath & "\Image\null.jpg")
        Me.PictureBox1.ImageLocation = Application.StartupPath & "\Image\null.jpg"
    End Sub
    
    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        If e.RowIndex >= 0 Then
            TextBox1.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(0).Value.ToString)
            TextBox2.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(1).Value.ToString)
            ComboBox1.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(2).Value.ToString)
            DateTimePicker1.Value = Trim(DataGridView1.Rows(e.RowIndex).Cells(3).Value.ToString)
            ComboBox2.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(4).Value.ToString)
            TextBox3.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(5).Value.ToString)
            TextBox5.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(6).Value.ToString)

            cn = New SqlConnection(strConn)
            cm = New SqlCommand
            cm.Connection = cn
            cm.CommandText = "select * from [学生信息表] where 学生学号='" & Trim(TextBox1.Text) & "'"
            cn.Open()
            myReader = cm.ExecuteReader
            If myReader.Read Then
                If myReader("联系邮箱") Is DBNull.Value Then
                    TextBox4.Text = ""
                Else
                    TextBox4.Text = myReader("联系邮箱")
                End If
                If myReader("政治面貌") Is DBNull.Value Then
                    ComboBox3.Text = "群众"
                Else
                    ComboBox3.Text = myReader("政治面貌")
                End If
                If myReader("第二联系人") Is DBNull.Value Then
                    TextBox7.Text = ""
                Else
                    TextBox7.Text = myReader("第二联系人")
                End If
                If myReader("第二联系人电话") Is DBNull.Value Then
                    TextBox6.Text = ""
                Else
                    TextBox6.Text = myReader("第二联系人电话")
                End If
                If myReader("家庭地址") Is DBNull.Value Then
                    TextBox8.Text = ""
                Else
                    TextBox8.Text = myReader("家庭地址")
                End If
                If myReader("学生照片") Is DBNull.Value Then
                    Me.PictureBox1.Image = Image.FromFile(Application.StartupPath & "\Image\null.jpg")
                    Me.PictureBox1.ImageLocation = Application.StartupPath & "\Image\null.jpg"
                Else
                    Me.PictureBox1.Image = GetImage(myReader("学生照片"))
                    Me.PictureBox1.ImageLocation = ""
                End If
                myReader.Close()
                cn.Close()
            End If
        End If
    End Sub
    
    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        If Trim(TextBox9.Text) = "" Then
            ReadStuInfo()
        Else
            ReadStuInfo1(Trim(TextBox9.Text))
        End If
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Form7_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ModMain.GetConn()
        ReadStuInfo()
        ComboBox1.Items.Add("男")
        ComboBox1.Items.Add("女")
        ComboBox1.Text = "男"
        ComboBox2.Items.Add("通信工程学院")
        ComboBox2.Items.Add("机电工程学院")
        ComboBox2.Items.Add("经济学院")
        ComboBox2.Items.Add("机械工程学院")
        ComboBox2.Items.Add("工商管理学院")
        ComboBox2.Items.Add("外语学院")

        ComboBox3.Items.Add("群众")
        ComboBox3.Items.Add("团员")
        ComboBox3.Items.Add("党员")
        ComboBox3.Text = "群众"

        ComboBox4.Items.Add("学生学号")
        ComboBox4.Items.Add("学生姓名")
        ComboBox4.Items.Add("所属院系")
        ComboBox4.Items.Add("所属班级")
        ComboBox4.Items.Add("政治面貌")
        ComboBox4.Items.Add("学生性别")
        ComboBox4.Text = ComboBox4.Items(0)
    End Sub
End Class