/*创建数据库*/
CREATE DATABASE StuInfoManage
ON
(NAME='StuInfoManage',
FILENAME='d:\数据库\StuInfoManage.mdf',
SIZE=10MB,
MAXSIZE=100MB,
FILEGROWTH=5%
)
LOG ON
(NAME='StuInfoManage_Log',
FILENAME='d:\数据库\StuInfoManage_Log.ldf',
SIZE=2MB,
MAXSIZE=10MB,
FILEGROWTH=1MB
)
Go

USE StuInfoManage
CREATE TABLE 学生信息表
(St_ID char(10) NOT NULL PRIMARY KEY,
St_Name varchar(20) NOT NULL,
St_Sex char(2) NOT NULL,
Born_Date datetime NULL,
Cl_No char(4) NULL,
Telephone varchar(20) NULL,
Address varchar(15) NULL,
IDCard char(18) NULL,
Photo image NULL,
Resume varchar(255) NULL
)
GO

USE StuInfoManage
CREATE TABLE 院系信息表
(Cl_No char(4) NOT NULL PRIMARY KEY,
Cl_Name varchar(60) NOT NULL
)
GO

USE StuInfoManage
CREATE TABLE 课程信息表
(C_No char(10) NOT NULL PRIMARY KEY,
C_Name varchar(30) NOT NULL,
C_Type char(4) NULL,
C_Credit real NOT NULL,
C_Des varchar(255) NULL
)
GO

USE StuInfoManage
CREATE TABLE 学生成绩表
(St_ID char(10) NOT NULL,
C_No char(10) NOT NULL,
score int NULL
)
GO

USE StuInfoManage
CREATE TABLE 用户信息表
(UserName varchar(40) NOT NULL PRIMARY KEY,
Password varchar(40) NOT NULL,
UserType varchar(20) NOT NULL
)
GO

alter table 学生信息表 add constraint S_C_1 foreign key(Cl_No)  references 院系信息表(Cl_No) 
alter table 学生成绩表 add constraint S_C_2 foreign key(St_ID)  references 学生信息表(St_ID) 
alter table 学生成绩表 add constraint S_C_3 foreign key(C_No)  references 课程信息表(C_No)
INSERT INTO 用户信息表 VALUES ('2','2','管理员')
INSERT INTO 用户信息表 VALUES ('1','1','管理员')
