﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Form2
    Dim sqlcn As SqlConnection
    Dim sqlcmd As SqlCommand

    Private Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("用户名和密码不能为空")
        ElseIf TextBox3.Text = "" Then
            MsgBox("请确认密码")
            Exit Sub
        End If
        sqlcn = New SqlConnection
        sqlcn.ConnectionString = "server=(local);database=article;Integrated Security=True"
        sqlcn.Open()
        Dim sql = "select count(userid) from userinfo where userid='" & TextBox1.Text & "'"
        sqlcmd = New SqlCommand(sql)
        sqlcmd.Connection = sqlcn
        Dim recount = sqlcmd.ExecuteScalar()
        If recount = 0 Then
            MsgBox("注册成功")
            Dim 
            Me.Close()
        Else
            MsgBox("用户名已存在")
        End If
    End Sub
End Class