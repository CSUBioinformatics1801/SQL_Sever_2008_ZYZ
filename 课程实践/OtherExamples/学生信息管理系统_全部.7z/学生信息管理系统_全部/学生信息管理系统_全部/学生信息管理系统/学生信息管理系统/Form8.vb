﻿Imports System.Data.SqlClient
Public Class Form8
    Dim cn As SqlConnection
    Dim cm As SqlCommand
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim myReader As SqlDataReader
    Dim TTs As String
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
    Private Sub ReadSocre()
        cn = New SqlConnection(strConn)
        '这里的链接默认就是打开的
        da = New SqlDataAdapter("select * from [成绩信息表]", cn)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Columns(0).Width = 120
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 120
        DataGridView1.Columns(3).Width = 150
    End Sub
    Private Sub ReadSocre1(ByVal s1 As String)
        cn = New SqlConnection(strConn)
        '这里的链接默认就是打开的
        da = New SqlDataAdapter("select * from [成绩信息表] where 学生学号 like '%" & s1 & "%'", cn)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Columns(0).Width = 120
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 120
        DataGridView1.Columns(3).Width = 150
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Trim(TextBox1.Text) = "" Then
            ReadSocre()
        Else
            ReadSocre1(Trim(TextBox1.Text))
        End If
    End Sub

    Private Sub Form8_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ReadSocre()
    End Sub
End Class