create table article
(title varchar(200) not null,
articletype char(10) not null,
publishtime datetime not null,
author char(30) not null,
field char(10)
primary key(title))
go
create table abstract
(title varchar(200),
abstract varchar(800)
primary key(title))
go
create table userinfo
(userid char(10),
userpassword char(20)
primary key(userid))
go
