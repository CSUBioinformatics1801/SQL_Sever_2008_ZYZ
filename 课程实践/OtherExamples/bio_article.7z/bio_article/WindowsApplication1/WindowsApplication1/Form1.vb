﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Form1
    Dim sqlcn As SqlConnection
    Dim sqlcmd As SqlCommand
    Private Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MsgBox("请输入用户名和密码")
            Exit Sub
        End If
        sqlcn = New SqlConnection
        sqlcn.ConnectionString = "server=(local);database=article;Integrated Security=True"
        sqlcn.Open()
        Dim sql = "select cnt=count(*) from userinfo where userid='" & Trim(TextBox1.Text) & "' and userpassword='" & Trim(TextBox2.Text) & "'"
        sqlcmd = New SqlCommand(Sql)
        sqlcmd.Connection = sqlcn
        Dim recount = sqlcmd.ExecuteScalar()
        If recount = 0 Then
            MsgBox("用户名和密码错误")
        Else
            Form3.Show()
            Me.Close()
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button2.Click
        Form2.Show()
    End Sub
End Class
