﻿Imports System.Data.SqlClient
Public Class Form1
    Dim cn As SqlConnection
    Dim cm As SqlCommand
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim myReader As SqlDataReader

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Trim(TextBox1.Text) = "" Then
            MsgBox("用户名不能为空,请输入登录用户名", vbOKOnly, "请输入用户名")
            Exit Sub
        End If
        If Trim(TextBox2.Text) = "" Then
            MsgBox("密码不能为空,请输入登录密码", vbOKOnly, "请输入登陆密码")
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [用户信息表] where 用户编号='" & Trim(TextBox1.Text) & "' and 用户密码='" & TextBox2.Text & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            UserName = TextBox1.Text
            UserType = Trim(myReader("用户类型").ToString)
            UserPassWord = TextBox2.Text
            If UserType = "普通用户" Then
                Form2.Show()
            ElseIf UserType = "管理员" Then
                Form2.Show()
            End If
            Me.Close()
        Else
            MsgBox("用户名或者密码错误，请检查！", vbOKOnly)
            TextBox1.Text = ""
            TextBox2.Text = ""
        End If
        myReader.Close()
        cn.Close()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ModMain.GetConn()
    End Sub
End Class
