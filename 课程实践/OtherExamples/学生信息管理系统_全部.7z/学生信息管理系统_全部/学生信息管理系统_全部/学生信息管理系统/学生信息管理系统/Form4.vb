﻿Imports System.Data.SqlClient
Public Class Form4
    Dim cn As SqlConnection
    Dim cm As SqlCommand
    Dim da As SqlDataAdapter
    Dim ds As DataSet
    Dim myReader As SqlDataReader

    Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ModMain.GetConn()
        ReadKCInfo()
        ComboBox1.Items.Add("必修")
        ComboBox1.Items.Add("选修")
        ComboBox1.Items.Add("课外")

        ComboBox2.Items.Add("课程编号")
        ComboBox2.Items.Add("课程名称")
        ComboBox2.Items.Add("课程类型")
        ComboBox2.Items.Add("授课教师")
        ComboBox2.Items.Add("授课教室")
        ComboBox2.Items.Add("课程课时")
        ComboBox2.Items.Add("课程学时")
        ComboBox2.Items.Add("课程学分")
        ComboBox2.Items.Add("课程描述")
        ComboBox2.Text = ComboBox2.Items(0)
    End Sub
    Private Sub ReadKCInfo()
        cn = New SqlConnection(strConn)
        '这里的链接默认就是打开的
        da = New SqlDataAdapter("select * from [课程信息表]", cn)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Columns(0).Width = 100
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 100
        DataGridView1.Columns(3).Width = 100
        DataGridView1.Columns(4).Width = 100
        DataGridView1.Columns(5).Width = 100
        DataGridView1.Columns(6).Width = 100
        DataGridView1.Columns(7).Width = 100
        DataGridView1.Columns(8).Width = 270

        ClearT()
    End Sub
    Private Sub ReadKCInfo1(ByVal s1 As String)
        cn = New SqlConnection(strConn)
        '这里的链接默认就是打开的
        da = New SqlDataAdapter("select * from [课程信息表] where " & ComboBox2.Text & " like '%" & s1 & "%'", cn)
        Dim dt As New DataTable
        da.Fill(dt)
        DataGridView1.DataSource = dt
        DataGridView1.Columns(0).Width = 100
        DataGridView1.Columns(1).Width = 100
        DataGridView1.Columns(2).Width = 100
        DataGridView1.Columns(3).Width = 100
        DataGridView1.Columns(4).Width = 100
        DataGridView1.Columns(5).Width = 100
        DataGridView1.Columns(6).Width = 100
        DataGridView1.Columns(7).Width = 100
        DataGridView1.Columns(8).Width = 270

        ClearT()
    End Sub
    Private Sub ClearT()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""
        TextBox8.Text = ""
        ComboBox1.Text = ""
    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Then
            MsgBox("课程编号不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            MsgBox("课程名称不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If ComboBox1.Text = "" Then
            MsgBox("课程类型不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox3.Text = "" Then
            MsgBox("授课教师不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox4.Text = "" Then
            MsgBox("授课教室不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox5.Text = "" Then
            MsgBox("课程课时不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox6.Text = "" Then
            MsgBox("课程学时不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox7.Text = "" Then
            MsgBox("课程学分不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [课程信息表] where 课程编号='" & Trim(TextBox1.Text) & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            MsgBox("该课程编号已经存在，请使用其他课程编号进行添加！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        Else
            myReader.Close()
            cn.Close()
        End If
        cn = New SqlConnection(strConn)
        cn.Open()
        Dim SqlString As String = "INSERT INTO 课程信息表 VALUES ("
        SqlString = SqlString & "'" & Trim(TextBox1.Text) & "','" & Trim(TextBox2.Text) & "','" & Trim(ComboBox1.Text) & "','" & Trim(TextBox3.Text) & "','" & Trim(TextBox4.Text) & "'," & Trim(TextBox5.Text) & "," & Trim(TextBox6.Text) & "," & Trim(TextBox7.Text) & ",'" & Trim(TextBox8.Text) & "')"
        cm = New SqlCommand(SqlString, cn)
        cm.ExecuteNonQuery()
        cn.Close()
        MsgBox("课程信息添加完成！")
        ReadKCInfo()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Then
            MsgBox("课程编号不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            MsgBox("课程名称不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If ComboBox1.Text = "" Then
            MsgBox("课程类型不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox3.Text = "" Then
            MsgBox("授课教师不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox4.Text = "" Then
            MsgBox("授课教室不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox5.Text = "" Then
            MsgBox("课程课时不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox6.Text = "" Then
            MsgBox("课程学时不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        If TextBox7.Text = "" Then
            MsgBox("课程学分不能为空！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [课程信息表] where 课程编号='" & Trim(TextBox1.Text) & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            myReader.Close()
            cn.Close()
        Else
            MsgBox("该课程编号的课程信息不存在，请检查！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cn.Open()
        Dim SqlString As String
        SqlString = "UPDATE 课程信息表 SET 课程名称='" & Trim(TextBox2.Text) & "',"
        SqlString = SqlString & "课程类型='" & Trim(ComboBox1.Text) & "',"
        SqlString = SqlString & "授课教师='" & Trim(TextBox3.Text) & "',"
        SqlString = SqlString & "授课教室='" & Trim(TextBox4.Text) & "',"
        SqlString = SqlString & "课程课时='" & Trim(TextBox5.Text) & "',"
        SqlString = SqlString & "课程学时='" & Trim(TextBox6.Text) & "',"
        SqlString = SqlString & "课程学分='" & Trim(TextBox7.Text) & "', "
        SqlString = SqlString & "课程描述='" & Trim(TextBox8.Text) & "' "
        SqlString = SqlString & "where 课程编号='" & Trim(TextBox1.Text) & "'"
        cm = New SqlCommand(SqlString, cn)
        cm.ExecuteNonQuery()
        cn.Close()
        MsgBox("课程信息修改成功！", vbOKOnly + vbInformation, "提示信息：")
        ReadKCInfo()
    End Sub
    Private Sub DataGridView1_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DataGridView1.CellMouseClick
        If e.RowIndex >= 0 Then
            TextBox1.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(0).Value.ToString)
            TextBox2.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(1).Value.ToString)
            ComboBox1.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(2).Value.ToString)
            TextBox3.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(3).Value.ToString)
            TextBox4.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(4).Value.ToString)
            TextBox5.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(5).Value.ToString)
            TextBox6.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(6).Value.ToString)
            TextBox7.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(7).Value.ToString)
            TextBox8.Text = Trim(DataGridView1.Rows(e.RowIndex).Cells(8).Value.ToString)
        End If
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Then
            MsgBox("课程编号不能为空，请先选择要删除的课程信息！", vbOKOnly + vbInformation, "提示信息：")
            Exit Sub
        End If
        cn = New SqlConnection(strConn)
        cm = New SqlCommand
        cm.Connection = cn
        cm.CommandText = "select * from [课程信息表] where 课程编号='" & Trim(TextBox1.Text) & "'"
        cn.Open()
        myReader = cm.ExecuteReader
        If myReader.Read Then
            myReader.Close()
            cn.Close()
        Else
            MsgBox("该课程编号在数据库中不存在，请检查！", vbInformation + vbOKOnly, "提示信息")
            myReader.Close()
            cn.Close()
            Exit Sub
        End If
        Dim temp As MsgBoxResult
        temp = MsgBox("确实要删除此条课程信息记录吗?", MsgBoxStyle.YesNo, "提示信息:")
        If temp = MsgBoxResult.Yes Then
            cn = New SqlConnection(strConn)
            cm = New SqlCommand
            cm.Connection = cn
            cm.CommandText = "delete from [课程信息表] where 课程编号 ='" & Trim(TextBox1.Text) & "'"
            cn.Open()
            cm.ExecuteNonQuery()
            cn.Close()
            ReadKCInfo()
        Else
            Exit Sub
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        If Trim(TextBox9.Text) = "" Then
            ReadKCInfo()
        Else
            ReadKCInfo1(Trim(TextBox9.Text))
        End If
    End Sub
End Class