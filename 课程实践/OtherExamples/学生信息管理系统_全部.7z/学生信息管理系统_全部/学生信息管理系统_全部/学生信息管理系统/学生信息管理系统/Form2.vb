﻿Public Class Form2

    Private Sub 学生信息管理ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 学生信息管理ToolStripMenuItem.Click
        Form3.Show()
    End Sub

    Private Sub 课程信息管理ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 课程信息管理ToolStripMenuItem.Click
        Form4.Show()
    End Sub

    Private Sub 班级信息管理ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 班级信息管理ToolStripMenuItem.Click
        Form5.Show()
    End Sub

    Private Sub 成绩信息管理ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 成绩信息管理ToolStripMenuItem.Click
        Form6.Show()
    End Sub

    Private Sub 学生信息查询ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 学生信息查询ToolStripMenuItem.Click
        Form7.Show()
    End Sub

    Private Sub 成绩信息查询ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 成绩信息查询ToolStripMenuItem.Click
        Form8.Show()
    End Sub

    Private Sub 信息管理ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 信息管理ToolStripMenuItem.Click

    End Sub

    Private Sub Form2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If UserType <> "管理员" Then
            信息管理ToolStripMenuItem.Visible = False
        End If
    End Sub

    Private Sub 退出系统QToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles 退出系统QToolStripMenuItem.Click
        If MsgBox("您确定要退出学生信息管理系统", vbYesNo, "提示") = MsgBoxResult.Yes Then
            Me.Close()
        End If
    End Sub
End Class